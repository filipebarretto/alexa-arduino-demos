# -*- coding: utf-8 -*-


WELCOME_MESSAGE = ("Bem vindo à demonstração de atuadores de IoT.  ")

HELP_MESSAGE = ("O que gostaria de saber? ")

EXIT_SKILL_MESSAGE = ("Até a próxima ")



